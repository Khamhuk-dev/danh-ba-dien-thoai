# Quản lý danh bạ điện thoại

Chương trình minh họa cho đồ án "Quản lý danh bạ điện thoại" (Chương 5 của
báo cáo). Cài đặt đúng theo kiến trúc MVC + Service đã mô tả ở Chương 4:
JavaFX (view) → Controller → Service (JDBC) → MySQL.

## 1. Công cụ / thư viện cần có (Bảng 5.1)

| Công cụ / thư viện | Phiên bản gợi ý |
|---|---|
| Java JDK | 21 |
| JavaFX / OpenJFX | 21.0.2 |
| MySQL Server | 8.x |
| MySQL Connector/J | 8.0.33 |
| Maven | 3.9+ |
| IDE | Visual Studio Code |

### Extension VS Code cần cài

- **Extension Pack for Java** (Microsoft) — gồm Language Support for Java,
  Debugger for Java, Test Runner, Maven for Java.
- (Tùy chọn) **MySQL** (weijan.mysql hoặc tương đương) nếu muốn xem dữ liệu
  ngay trong VS Code thay vì dùng MySQL Workbench.

Sau khi cài xong, mở thư mục `quan_ly_danh_ba` bằng `code .` hoặc
`File → Open Folder...`. VS Code sẽ tự nhận `pom.xml` và tải các
dependency (JavaFX, MySQL Connector/J) về `~/.m2/repository` — cần có
mạng ở bước này.

## 2. Cài đặt cơ sở dữ liệu

1. Mở MySQL Workbench (hoặc `mysql` CLI) và chạy toàn bộ script
   `sql/danh_ba.sql`. Script sẽ tạo database `danh_ba`, 4 bảng
   (`nguoi_dung`, `nhom`, `lien_he`, `so_dien_thoai`) đúng theo Bảng
   4.1–4.4, kèm một tài khoản và dữ liệu mẫu để chạy thử.
2. Tài khoản đăng nhập mẫu: **admin / admin123**.
3. Mở `src/main/resources/db.properties` và sửa `db.url`, `db.user`,
   `db.password` cho đúng với MySQL trên máy bạn.

## 3. Chạy chương trình trong VS Code

Project đã kèm sẵn `.vscode/tasks.json` với 2 task:

- **Chạy chương trình (javafx:run)** — mặc định khi nhấn `Ctrl+Shift+B`
  (Terminal → Run Build Task), tương đương lệnh `mvn clean javafx:run`.
- **Build jar (package)** — đóng gói thành file `.jar` trong thư mục `target/`.

Cách chạy nhanh:

1. Mở Terminal tích hợp trong VS Code (`` Ctrl+` ``).
2. Gõ lệnh:

   ```bash
   mvn clean javafx:run
   ```

   (hoặc nhấn `Ctrl+Shift+P` → gõ *Tasks: Run Task* → chọn
   **Chạy chương trình (javafx:run)**).

> Lưu ý: nút ▶ "Run" phía trên hàm `main` trong `Main.java` (do Debugger
> for Java cung cấp) **sẽ báo lỗi** `Error: JavaFX runtime components are
> missing` nếu chạy trực tiếp, vì JavaFX cần được nạp qua
> `javafx-maven-plugin` (module-path) chứ không chỉ classpath thường. Vì
> vậy luôn chạy chương trình bằng task/lệnh `mvn javafx:run` ở trên thay
> vì nút Run/Debug mặc định.

## 4. Cấu trúc thư mục (Bảng 4.5 - Thiết kế các gói)

```
src/main/java/com/danhba/
  Main.java                  # goi main - diem khoi dong
  model/                     # NguoiDung, LienHe, SoDienThoai, Nhom
  service/                   # MysqlConnector, NguoiDungService,
                             # LienHeService, NhomService, CsvService
  controller/                # DangNhapController, LienHeController,
                             # FormLienHeController, NhomController,
                             # ThongKeController
  util/                      # Validator, PasswordUtil
src/main/resources/
  view/                      # dang_nhap.fxml, chinh.fxml,
                             # form_lien_he.fxml, nhom.fxml, thong_ke.fxml
  db.properties
sql/
  danh_ba.sql                # script tao CSDL (Phu luc - Chuong 4.2)
```

## 5. Các chức năng đã cài đặt (đối chiếu Chương 2 - Đặc tả yêu cầu)

| Use case | Màn hình | Trạng thái |
|---|---|---|
| UC01 Đăng nhập | `dang_nhap.fxml` | Hoàn thành |
| UC02 Xem danh sách liên hệ | `chinh.fxml` | Hoàn thành |
| UC03 Thêm liên hệ | `form_lien_he.fxml` | Hoàn thành |
| UC04 Sửa liên hệ | `form_lien_he.fxml` | Hoàn thành |
| UC05 Xóa liên hệ | `chinh.fxml` | Hoàn thành |
| UC06 Tìm kiếm liên hệ | `chinh.fxml` | Hoàn thành |
| UC07 Đánh dấu yêu thích | `chinh.fxml` | Hoàn thành |
| UC08-UC11 Quản lý nhóm | `nhom.fxml` | Hoàn thành |
| UC12 Nhập danh bạ từ CSV | `chinh.fxml` (hộp thoại chọn file) | Hoàn thành |
| UC13 Xuất danh bạ ra CSV | `chinh.fxml` (hộp thoại chọn file) | Hoàn thành |
| UC14 Thống kê danh bạ | `thong_ke.fxml` | Hoàn thành |

Dùng bảng này để điền mục **5.2. Kết quả chương trình minh họa** trong báo
cáo (14/14 use case, cấu trúc thư mục như trên, số dòng mã có thể lấy bằng
`find src -name "*.java" | xargs wc -l` sau khi mở project).

## 6. Định dạng file CSV (UC12, UC13)

```
ho_ten,so_dien_thoai,email,dia_chi,ten_nhom
Nguyễn Văn A,0901234567,a@example.com,Hà Nội,Gia đình
```

Cột `ten_nhom` là tùy chọn; nếu để trống hoặc tên nhóm chưa tồn tại,
liên hệ sẽ được nhập vào trạng thái "chưa phân nhóm".

## 7. Ghi chú để chụp ảnh màn hình cho mục 5.3 của báo cáo

Sau khi chạy chương trình thành công, chụp màn hình lần lượt theo đúng
thứ tự các mục 5.3.1–5.3.6 đã có sẵn trong báo cáo:
đăng nhập → danh sách & tìm kiếm → thêm/sửa/xóa → quản lý nhóm →
nhập/xuất CSV → thống kê.
